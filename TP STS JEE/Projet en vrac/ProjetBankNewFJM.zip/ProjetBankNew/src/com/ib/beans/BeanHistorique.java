package com.ib.beans;

public class BeanHistorique {
	
	private int	ope_id;
	private String ope_type;	
	private String ope_amount;
	private String ope_description;
	private String ope_account_id;
	private String ope_created_at;
	private String ope_updated_at;
	private int ope_dispute;
	
	public BeanHistorique() {
	}

	public int getOpe_id() {
		return ope_id;
	}

	public void setOpe_id(int ope_id) {
		this.ope_id = ope_id;
	}

	public String getOpe_type() {
		return ope_type;
	}

	public void setOpe_type(String ope_type) {
		this.ope_type = ope_type;
	}

	public String getOpe_amount() {
		return ope_amount;
	}

	public void setOpe_amount(String ope_amount) {
		this.ope_amount = ope_amount;
	}

	public String getOpe_description() {
		return ope_description;
	}

	public void setOpe_description(String ope_description) {
		this.ope_description = ope_description;
	}

	public String getOpe_account_id() {
		return ope_account_id;
	}

	public void setOpe_account_id(String ope_account_id) {
		this.ope_account_id = ope_account_id;
	}

	public String getOpe_created_at() {
		return ope_created_at;
	}

	public void setOpe_created_at(String ope_created_at) {
		this.ope_created_at = ope_created_at;
	}

	public String getOpe_updated_at() {
		return ope_updated_at;
	}

	public void setOpe_updated_at(String ope_updated_at) {
		this.ope_updated_at = ope_updated_at;
	}

	public int getOpe_dispute() {
		return ope_dispute;
	}

	public void setOpe_dispute(int ope_dispute) {
		this.ope_dispute = ope_dispute;
	}
	
	

}
