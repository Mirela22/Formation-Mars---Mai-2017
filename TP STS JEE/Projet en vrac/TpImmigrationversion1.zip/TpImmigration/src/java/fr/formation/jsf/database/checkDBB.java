
package fr.formation.jsf.database;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;
import com.mysql.jdbc.Statement;
import fr.formation.jsf.personn.PersonnBean;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;


@ManagedBean(name="loggin")
@SessionScoped
public class checkDBB {
    
    
    public void checkLog(String name, String mdp){
        
    }
    
    
    
    
}
